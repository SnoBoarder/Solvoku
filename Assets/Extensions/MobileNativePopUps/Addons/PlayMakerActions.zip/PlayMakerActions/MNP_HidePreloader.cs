﻿using UnityEngine;
using System.Collections;

namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("Mobile Native Pop-ups")]
	public class MNP_HidePreloader : FsmStateAction {
 
		
		public override void OnEnter() {
			MNP.HidePreloader();
			Finish();	
		}


	}
}


